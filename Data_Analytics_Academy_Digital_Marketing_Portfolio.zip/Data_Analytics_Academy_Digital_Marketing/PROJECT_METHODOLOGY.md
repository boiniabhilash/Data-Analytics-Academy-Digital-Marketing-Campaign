# Project Methodology

## Status
**Portfolio campaign simulation — not live campaign execution.**

## Actual portfolio work represented
- Research framework
- Audience/persona strategy
- Funnel design
- Campaign architecture
- Creative concepts and storyboards
- Ad copy
- Landing-page copy/prototype
- Lead capture flow
- Media plan
- Tracking/KPI framework
- A/B testing plan
- Optimization framework
- Retargeting
- Lead nurture sequence
- Final case study
- GitHub and LinkedIn copy
- Resume-ready project entry

## Not represented as actual
- Live Meta ad spend
- Actual impressions/reach/clicks
- Actual leads
- Actual enrollments
- Actual revenue
- Actual CTR/CPC/CPL/CAC/ROAS

## Future upgrade
If a real campaign is later run, replace hypothetical KPI scenarios with exported Meta/landing-page/CRM data and document the dates, spend, audience, attribution window and actual outcomes.
